/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.tangent.web.controller;

/**
 *
 * @author F4829689
 */
public class ResourceSet {
    
}
